package com.mawi.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MawiAccessibilityService : AccessibilityService() {

    companion object {
        var instance: MawiAccessibilityService? = null
    }

    private var flashOn = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screen events monitor karte raho
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ─── SCROLL ───────────────────────────────────────────
    fun scrollDown() {
        val displayMetrics = resources.displayMetrics
        val height = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels

        val path = Path().apply {
            moveTo(width / 2f, height * 0.7f)
            lineTo(width / 2f, height * 0.3f)
        }
        performGesture(path, 300)
    }

    fun scrollUp() {
        val displayMetrics = resources.displayMetrics
        val height = displayMetrics.heightPixels
        val width = displayMetrics.widthPixels

        val path = Path().apply {
            moveTo(width / 2f, height * 0.3f)
            lineTo(width / 2f, height * 0.7f)
        }
        performGesture(path, 300)
    }

    private fun performGesture(path: Path, duration: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build()
            dispatchGesture(gesture, null, null)
        }
    }

    // ─── NAVIGATION ───────────────────────────────────────
    fun pressBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun pressHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun openRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun openNotifications() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun openQuickSettings() {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    // ─── VOLUME ───────────────────────────────────────────
    fun volumeUp() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    }

    fun volumeDown() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    fun muteVolume() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
    }

    // ─── FLASHLIGHT ───────────────────────────────────────
    fun toggleFlashlight() {
        try {
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            flashOn = !flashOn
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, flashOn)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun flashlightOn() {
        flashOn = false
        toggleFlashlight()
    }

    fun flashlightOff() {
        flashOn = true
        toggleFlashlight()
    }

    // ─── CLICK NODE ───────────────────────────────────────
    fun clickOnText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        nodes.forEach { node ->
            if (node.isClickable) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
            val parent = node.parent
            if (parent?.isClickable == true) {
                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
        }
        return false
    }

    // ─── TYPE TEXT ────────────────────────────────────────
    fun typeText(text: String) {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        focused?.let {
            val args = android.os.Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }

    // ─── LIKE (Instagram/YouTube) ─────────────────────────
    fun tapLike() {
        val likeTexts = listOf("Like", "J'aime", "पसंद", "like")
        for (text in likeTexts) {
            if (clickOnText(text)) return
        }
        // Double tap center screen (Instagram like)
        doubleTapCenter()
    }

    private fun doubleTapCenter() {
        val displayMetrics = resources.displayMetrics
        val cx = displayMetrics.widthPixels / 2f
        val cy = displayMetrics.heightPixels / 2f

        val path = Path().apply { moveTo(cx, cy); lineTo(cx, cy) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val tap1 = GestureDescription.StrokeDescription(path, 0, 50)
            val tap2 = GestureDescription.StrokeDescription(path, 200, 50)
            val gesture = GestureDescription.Builder().addStroke(tap1).addStroke(tap2).build()
            dispatchGesture(gesture, null, null)
        }
    }
}
