package com.mawi.ai

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class MawiTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile(false)
    }

    override fun onClick() {
        super.onClick()
        // Tile tap hone pe Voice Service shuru karo
        val tile = qsTile
        if (tile.state == Tile.STATE_INACTIVE) {
            // Mic ON karo
            updateTile(true)
            startVoiceCommand()
        } else {
            // Mic OFF karo
            updateTile(false)
            stopVoiceCommand()
        }
    }

    private fun updateTile(isActive: Boolean) {
        val tile = qsTile ?: return
        if (isActive) {
            tile.state = Tile.STATE_ACTIVE
            tile.label = "MAWI ON 🎙️"
        } else {
            tile.state = Tile.STATE_INACTIVE
            tile.label = "MAWI AI"
        }
        tile.updateTile()
    }

    private fun startVoiceCommand() {
        val intent = Intent(this, VoiceCommandService::class.java)
        intent.action = VoiceCommandService.ACTION_START
        startService(intent)
        // Panel band karo aur voice start karo
        collapseStatusBar()
    }

    private fun stopVoiceCommand() {
        val intent = Intent(this, VoiceCommandService::class.java)
        intent.action = VoiceCommandService.ACTION_STOP
        startService(intent)
        updateTile(false)
    }

    private fun collapseStatusBar() {
        try {
            val statusBarService = getSystemService("statusbar")
            val statusBarManager = Class.forName("android.app.StatusBarManager")
            val collapseMethod = statusBarManager.getMethod("collapsePanels")
            collapseMethod.invoke(statusBarService)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Voice command complete hone pe tile reset karo
    companion object {
        fun resetTile() {
            // Called from VoiceCommandService when done
        }
    }
}
