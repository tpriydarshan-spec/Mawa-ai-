package com.mawi.ai

import android.app.*
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

class VoiceCommandService : Service() {

    companion object {
        const val ACTION_START = "START_VOICE"
        const val ACTION_STOP = "STOP_VOICE"
        const val GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE" // Apni key yahan daalo
        const val CHANNEL_ID = "MAWI_CHANNEL"
        const val NOTIF_ID = 1
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val client = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private var isListening = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initTTS()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIF_ID, buildNotification("🎙️ Suno raha hoon..."))
                startListening()
            }
            ACTION_STOP -> {
                stopListening()
                stopForeground(true)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun initTTS() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition available nahi hai")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                updateNotification("🎙️ Bol MAWI...")
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = matches?.firstOrNull() ?: return

                updateNotification("🤔 Samajh raha hoon...")

                // MAWI wake word check
                if (command.lowercase().contains("mawi") || isListening) {
                    val cleanCommand = command.lowercase()
                        .replace("mawi", "")
                        .trim()
                    processCommand(cleanCommand)
                }
            }

            override fun onError(error: Int) {
                isListening = false
                stopSelf()
                // Tile reset karo
                val i = Intent(this@VoiceCommandService, MawiTileService::class.java)
                stopService(i)
            }

            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onRmsChanged(rmsdB: Float) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ALSO_RECOGNIZE_LANGS, "en-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun stopListening() {
        isListening = false
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun processCommand(command: String) {
        // Pehle local commands check karo (fast!)
        when {
            command.contains("whatsapp") && command.contains("kholo") -> {
                openApp("com.whatsapp")
                speak("WhatsApp khol raha hoon")
            }
            command.contains("youtube") && command.contains("kholo") -> {
                openApp("com.google.android.youtube")
                speak("YouTube khol raha hoon")
            }
            command.contains("instagram") && command.contains("kholo") -> {
                openApp("com.instagram.android")
                speak("Instagram khol raha hoon")
            }
            command.contains("camera") -> {
                openApp("com.android.camera2")
                speak("Camera khol raha hoon")
            }
            command.contains("torch") || command.contains("flashlight") || command.contains("torch on") -> {
                MawiAccessibilityService.instance?.toggleFlashlight()
                speak("Flashlight on kar diya")
            }
            command.contains("scroll") && command.contains("upar") -> {
                MawiAccessibilityService.instance?.scrollUp()
                speak("Upar scroll kiya")
            }
            command.contains("scroll") && command.contains("neeche") -> {
                MawiAccessibilityService.instance?.scrollDown()
                speak("Neeche scroll kiya")
            }
            command.contains("back") || command.contains("wapas") -> {
                MawiAccessibilityService.instance?.pressBack()
                speak("Wapas gaye")
            }
            command.contains("home") -> {
                MawiAccessibilityService.instance?.pressHome()
                speak("Home par aaye")
            }
            command.contains("volume") && command.contains("badha") -> {
                MawiAccessibilityService.instance?.volumeUp()
                speak("Volume badha diya")
            }
            command.contains("volume") && command.contains("kam") -> {
                MawiAccessibilityService.instance?.volumeDown()
                speak("Volume kam kar diya")
            }
            else -> {
                // Gemini AI se handle karwao complex commands
                askGemini(command)
            }
        }

        // Done - tile reset karo
        stopSelf()
    }

    private fun openApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent != null) startActivity(intent)
        else speak("Yeh app install nahi hai")
    }

    private fun askGemini(command: String) {
        scope.launch {
            try {
                val systemPrompt = """
                    Tu MAWI AI hai - ek Android voice assistant.
                    User ne yeh command diya: "$command"
                    
                    Agar command clear hai toh seedha response do Hindi mein (1-2 lines max).
                    Agar app open karna hai toh format: ACTION:OPEN_APP:package_name
                    Agar call karna hai: ACTION:CALL:number_or_name
                    Agar WhatsApp message: ACTION:WHATSAPP:contact:message
                    Baaki: Normal helpful response do Hindi mein.
                """.trimIndent()

                val json = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().put("text", systemPrompt))
                            })
                        })
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$GEMINI_API_KEY"

                val request = Request.Builder()
                    .url(url)
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string() ?: return@launch

                val responseJson = JSONObject(responseBody)
                val text = responseJson
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                // Actions parse karo
                withContext(Dispatchers.Main) {
                    when {
                        text.startsWith("ACTION:OPEN_APP:") -> {
                            val pkg = text.removePrefix("ACTION:OPEN_APP:")
                            openApp(pkg)
                        }
                        text.startsWith("ACTION:CALL:") -> {
                            val number = text.removePrefix("ACTION:CALL:")
                            makeCall(number)
                        }
                        text.startsWith("ACTION:WHATSAPP:") -> {
                            val parts = text.removePrefix("ACTION:WHATSAPP:").split(":")
                            if (parts.size >= 2) sendWhatsApp(parts[0], parts[1])
                        }
                        else -> speak(text)
                    }
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    speak("Kuch error aaya, dobara try karo")
                }
            }
        }
    }

    private fun makeCall(number: String) {
        val intent = Intent(Intent.ACTION_CALL, android.net.Uri.parse("tel:$number"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun sendWhatsApp(contact: String, message: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse("https://wa.me/?text=$message")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
            speak("WhatsApp khol raha hoon")
        } catch (e: Exception) {
            speak("WhatsApp nahi mila")
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "MAWI AI",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "MAWI AI Voice Assistant"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MAWI AI")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(content: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(content))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopListening()
        tts?.shutdown()
        scope.cancel()
    }
}
