package com.mawi.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkAndRequestPermissions()
        setupUI()
    }

    private fun setupUI() {
        val statusText = findViewById<TextView>(R.id.statusText)
        val startBtn = findViewById<Button>(R.id.startServiceBtn)
        val accessibilityBtn = findViewById<Button>(R.id.accessibilityBtn)
        val overlayBtn = findViewById<Button>(R.id.overlayBtn)
        val tileHintText = findViewById<TextView>(R.id.tileHintText)

        tileHintText.text = "💡 Quick Settings mein MAWI tile add karo!\n" +
                "Upar se swipe → Edit → MAWI AI drag karo"

        // Check accessibility
        if (!isAccessibilityEnabled()) {
            statusText.text = "⚠️ Accessibility Service enable karo"
            accessibilityBtn.visibility = android.view.View.VISIBLE
        } else {
            statusText.text = "✅ MAWI AI Ready!\nQuick Settings se activate karo"
            accessibilityBtn.visibility = android.view.View.GONE
        }

        startBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
            } else {
                startFloatingButton()
                Toast.makeText(this, "MAWI AI Started! 🎙️", Toast.LENGTH_SHORT).show()
            }
        }

        accessibilityBtn.setOnClickListener {
            openAccessibilitySettings()
        }

        overlayBtn.setOnClickListener {
            requestOverlayPermission()
        }
    }

    private fun startFloatingButton() {
        val intent = Intent(this, FloatingButtonService::class.java)
        startService(intent)
        finish()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "${packageName}/${MawiAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return enabled?.contains(service) == true
    }

    private fun openAccessibilitySettings() {
        AlertDialog.Builder(this)
            .setTitle("Accessibility Enable Karo")
            .setMessage("Settings → Accessibility → Installed Apps → MAWI AI → Enable karo")
            .setPositiveButton("Settings Kholo") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Baad Mein", null)
            .show()
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }
}
