# 🎙️ MAWI AI – Voice Assistant for Android

## Quick Settings Tile wala Voice Assistant!
Bilkul X Recorder jaisa – upar se swipe karo, MAWI tile tap karo, bol do!

---

## 📱 Features
- ✅ Quick Settings Tile (notification panel se activate)
- ✅ WhatsApp, YouTube, Instagram open karo
- ✅ Scroll up/down voice se
- ✅ Volume control
- ✅ Flashlight on/off
- ✅ Back/Home navigate
- ✅ Gemini AI se smart responses
- ✅ Hindi + English support
- ✅ Infinix Hot 9 compatible

---

## 🚀 GitHub Se APK Banao (FREE!)

### Step 1: GitHub Account
- github.com pe free account banao

### Step 2: New Repository
- "New Repository" click karo
- Name: `mawi-ai`
- Public rakho
- Create karo

### Step 3: Files Upload Karo
- Saari files is folder se upload karo
- Same folder structure maintain karo

### Step 4: Gemini API Key Secret Add Karo
- Repository → Settings → Secrets → Actions
- "New Repository Secret" click karo
- Name: `GEMINI_API_KEY`
- Value: Apni Gemini API key paste karo
- Save karo

### Step 5: APK Build Karo
- Actions tab pe jao
- "Build MAWI AI APK" workflow click karo
- "Run workflow" click karo
- 5-10 minute wait karo
- "MAWI-AI-APK" artifact download karo!

---

## 📲 Install Karo

1. APK download karo phone pe
2. Settings → Security → Unknown Sources → ON
3. APK install karo
4. MAWI AI open karo
5. Saari permissions do
6. Accessibility Service enable karo
7. Quick Settings mein MAWI tile add karo
8. **Done! 🎉**

---

## 🗣️ Voice Commands

| Command | Kya Hoga |
|---------|----------|
| MAWI, WhatsApp kholo | WhatsApp open |
| MAWI, YouTube kholo | YouTube open |
| MAWI, neeche scroll karo | Scroll down |
| MAWI, upar scroll karo | Scroll up |
| MAWI, volume badha | Volume up |
| MAWI, torch on karo | Flashlight on |
| MAWI, wapas jao | Back press |
| MAWI, home jao | Home press |
| MAWI, [koi bhi sawaal] | Gemini AI jawab dega |

---

## ⚙️ Setup After Install

1. **Accessibility**: Settings → Accessibility → MAWI AI → Enable
2. **Overlay**: MAWI app → Overlay Permission → Allow
3. **Quick Tile**: Notification panel → Edit → MAWI AI drag karo tiles mein

---

Made with ❤️ – MAWI AI v1.0
